# PatientTracker
A patient health management Android application to track patient health records like various illnesses, medicines prescribed and other vital records that can be used by a doctor to perform diagnostics. Patient Tracker  is an android  application for doctors,  designed to manage  their  patients in an efficient and easier way.  Patient Tracker  is everything a hospital record is and more. The app replaces the manual patient record.<br />
<br />
Additional Features including the ability to backup and restore data from a cloud server will be made avaiable in the Play Store version. Link will be added soon once it is published.<br />
